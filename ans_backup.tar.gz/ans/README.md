﻿# PPLive ansible

Set of playbooks for PP Live platform.\

## Inventories

Currently hosts grouped to stage* envs (devint,qa,etc...) and live. Look invetory dir to find more groups.\
Here described some non-platform inventories.

| Inventory | Purpose |
|---|---|
| devint*,qa*,prelive,training | Stages for pplive platform |
| stress | Dynamic ec2 inventory for [stress env](https://gitlab.livetechlabs.net/pplive/pplive-loadtest) |
| live | Dynamic ec2 inventory for [production env](https://gitlab.livetechlabs.net/pplive/pplive-prod) |


```sh
git submodule init && update
```

## Run playbook over choosen stage

```sh
ansible-playbook -i ./inventory/devint base.yml --diff
```

## Playbooks

### Base playbook - requires manuall triggering in GitlabCI pipeline for `live` env

Initial configuration, users management

### Monitoring playbook

Installs and configure nrpe (live only), telegraf, and filebeat.\

```sh
ansible-playbook -i inventory/live monitoring.yml
```

#### Stress env has no gitlab-ci automation, run it manually

```sh
ansible-playbook -i inventory/stress monitoring.yml --diff -e ansible_user=ansible
```

### Nginx-CDN playbook - requires manuall triggering in GitlabCI pipeline for `live` env

Manages nginx CDN hosts with tables mapping defined per region `tag_Name_ngx_asia|china|eu`

```sh
ansible-playbook -i inventory/live nginx-cdn.yml --check --diff
```

### Platform playbook - requires manuall triggering in GitlabCI pipeline for `live` env


```sh
ansible-playbook -i inventory/qa2 platform.yml --diff --check
```

### Setup cronjobs playbook
Task Tags:
- dm-cron - all dm related cronjobs
- app-log-cleanup - application log cleanup cronjobs
- nginx-logs-cleanup - nginx log cleanup cronjobs
- docker-log-cleanup - docker log cleanup cronjobs
- tcp-dump - tcp-dump related cronjobs
- tcp-dump-log-cleanup - tcp-dump log cleanup cronjob only
```sh
ansible-playbook -i inventory/live -l dm setup-cronjobs.yml --diff -e stage=${stage} -t app-log-cleanup
```

## DM - Dealermodule

[dm-configurations](https://gitlab.livetechlabs.net/pplive/deploy/dm-configurations) -
is git submodule which holds DM inventory and configurations.\
Here only ```dm-configurations/inventory``` used for hosts base setup with dm.yml playbook.\
[Triggered automatically](https://gitlab.livetechlabs.net/pplive/infra/cicd/-/blob/master/jjb/jobs/deploy/trigger-dm-ansible-base.yml) by Gilab hook to Jenkins.

```sh
ansible-playbook -i ./dm-configurations/inventory/live -l hostname dm.yml  -e ansible_user=host -e ansible_password=**** -e ansible_sudo_pass=****
```

P.S.
In some versions of Ansible:
ansible_sudo_pass => ansible_become_pass

## Adhocs

### remove_users.yml

**Note:** removing ansible-management users feature implemented in base-role, so this adhoc rather for quick removing or for not ansible-managed users.\
Use to remove linux hosts users per env:

```sh
ansible-playbook -i inventory/devint adhocs/remove_users.yml --diff
```

## [Ansible vault](https://docs.ansible.com/ansible/latest/user_guide/vault.html)

### Pass encryption string via file

```sh
export ANSIBLE_VAULT_PASSWORD_FILE=<VERY_SECRET_PATH>
```

### Encrypt variable

```sh
ansible-vault encrypt_string 'SECRETVALUE' --name 'KEY'
```

### View encrypted variable

```sh
 ansible localhost -m ansible.builtin.debug -a var="db_password" -e "@inventory/production/group_vars/db.yml"
```

## TODO

* split streaming and platform hosts to different groups
