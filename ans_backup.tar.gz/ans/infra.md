# Infra playbooks

## gitlab-runner.yml

Includes base host setup and gitlab-runner initialization. If re-registering required (e.g. with new set of tags)\
run it with ```-e gitlab_runner_force_register=True```

```sh
ansible-playbook -i inventory/infra gitlab-runner.yml --diff --check
```

## jenkins-agent.yml

Runs jenkins-agent which connects to jenkins-master via JNLP.

```sh
ansible-playbook -i inventory/infra jenkins-agent.yml --diff --check
```

## Studio host

Instance cicd-agent-studio is running in Studio office and requires VPN is connected to run playbooks over.

## Jenkins master

Configuration is managed with [JCASC](https://github.com/jenkinsci/configuration-as-code-plugin) plugin.

JCASC reload is triggered on file config change.

```sh
ansible-playbook -i inventory/infra jenkins-master.yml -CD
```

It's possible that some settings won't be applied with JCASC config reload, use `adhocs/jenkins-restart-container.yml` adhoc to restart jenkins container insuch cases.

```sh
ansible-playbook -i inventory/infra adhocs/jenkins-restart-container.yml -CD
```
