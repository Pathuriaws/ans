def f():


 pass
