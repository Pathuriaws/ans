#!/bin/bash

NOW=$(date +"%Y-%m-%d-%H-%M-%S")
BACKUP_NAME="vault-prod-$NOW"
FULL_PATH="/opt/backups/$BACKUP_NAME"
CONSUL_SERVER="http://127.0.0.1:8500/v1/snapshot?dc=prod"
BUCKET="s3://pplive-vault-backup-prod"

curl ${CONSUL_SERVER} --output ${FULL_PATH}
aws s3 cp ${FULL_PATH} ${BUCKET} --storage-class STANDARD_IA
find /opt/backups/ -type f -mtime +7 -exec rm -f {} +
