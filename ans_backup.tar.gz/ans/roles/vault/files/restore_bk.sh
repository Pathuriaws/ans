#!/bin/bash

BUCKET="s3://pplive-vault-backup-prod"
CONSUL_SERVER="http://127.0.0.1:8500/v1/snapshot?dc=prod"

FILE_NAME=$(aws s3 ls $BUCKET --recursive | sort | tail -n 1 | awk '{print $4}')
aws s3 cp $BUCKET/${FILE_NAME} .
curl --request PUT --data-binary @${FILE_NAME} ${CONSUL_SERVER}
rm -rf ${FILE_NAME}
