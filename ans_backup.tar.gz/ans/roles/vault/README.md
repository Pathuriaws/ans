# Vault cluster

## Run command for instal consul and vault and set env ( stage=prod )

```sh
ansible-playbook service_vault.yaml -i inventory/vault --user ubuntu  --tags "consul"
ansible-playbook service_vault.yaml -i inventory/vault --user ubuntu  --tags "vault"
```
