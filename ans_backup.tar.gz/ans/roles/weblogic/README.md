# weblogic seutup

## Apply only systemd service change over casino, casino2

```sh
ansible-playbook -i inventory/devint weblogic.yml -D -t weblogic-systemd-service -e weblogic_domain_name=casino
ansible-playbook -i inventory/devint weblogic.yml -D -t weblogic-systemd-service -e weblogic_domain_name=casino2
```
