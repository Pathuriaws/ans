const translations = {
  "en": {
    "maintenance": "Scheduled maintenance",
    "infoText": "We are currently upgrading to bring you a better gaming experience.",
    "backShortly": "We will be back shortly..."
  },
  "fr": {
    "maintenance": "Maintenance programmée ",
    "infoText": "Nous sommes actuellement en cours d'amélioration afin de vous offrir une meilleure expérience de jeu.",
    "backShortly": "Nous serons bientôt de retour..."
  },
  "it": {
    "maintenance": "Manutenzione ordinaria",
    "infoText": "Stiamo applicando un aggiornamento per migliorare l'esperienza di gioco.",
    "backShortly": "Torneremo presto..."
  },
  "de": {
    "maintenance": "Wartung geplant",
    "infoText": "Wir führen derzeit ein Upgrade für ein besseres Spielerlebnis durch.",
    "backShortly": "Wir sind in Kürze wieder da ..."
  },
  "es": {
    "maintenance": "¡Mantenimiento programado",
    "infoText": "En estos momentos estamos actualizando para traerle una mejor experiencia de juego.",
    "backShortly": "Estaremos pronto de vuelta..."
  },
  "pt": {
    "maintenance": "Manutenção agendada",
    "infoText": "Estamos a fazer atualizações para lhe dar uma melhor experiência de jogo.",
    "backShortly": "Voltaremos brevemente..."
  },
  "sv": {
    "maintenance": "Planerat underhåll",
    "infoText": "Vi håller på att uppgradera för att ge dig en bättre spelupplevelse.",
    "backShortly": "Vi är strax tillbaka..."
  },
  "no": {
    "maintenance": "Planlagt vedlikehold",
    "infoText": "Vi oppgraderer for øyeblikket for å gi deg en bedre spillopplevelse.",
    "backShortly": "Vi er straks tilbake..."
  },
  "fi": {
    "maintenance": "Suunniteltu huolto",
    "infoText": "Teemme tällä hetkellä päivitystä, jotta voimme tarjota entistäkin parempia pelikokemuksia.",
    "backShortly": "Palaamme pian..."
  },
  "pl": {
    "maintenance": "Zaplanowana konserwacja",
    "infoText": "Pracujemy nad zapewnieniem jeszcze lepszych wrażeń podczas gry.",
    "backShortly": "Niedługo wracamy..."
  },
  "sr": {
    "maintenance": "Planirano održavanje",
    "infoText": "Trenutno ažuriramo sistem da bismo vam pružili bolji užitak u igrama.",
    "backShortly": "Brzo se vraćamo..."
  },
  "bg": {
    "maintenance": "Планирана поддръжка",
    "infoText": "В момента извършваме актуализация, за да Ви предоставим по-добро изживяване, докато играете.",
    "backShortly": "Ще се върнем скоро..."
  },
  "tr": {
    "maintenance": "Planlı bakım",
    "infoText": "Size daha iyi bir oyun deneyimi sunabilmek için güncelleniyoruz.",
    "backShortly": "Kısa zamanda döneceğiz..."
  },
  "zh": {
    "maintenance": "计划维护！",
    "infoText": "我们正在升级，以便为您带来更好的游戏体验。",
    "backShortly": "我们很快就回来…"
  },
  "zt": {
    "maintenance": "計畫維護！",
    "infoText": "我們正在升級，以便為您帶來更好的遊戲體驗。",
    "backShortly": "我們很快就回來…"
  },
  "th": {
    "maintenance": "ปิดปรับปรุงตามกำหนดเวลา",
    "infoText": "ขณะนี้เรากำลังอัปเกรดเพื่อนำประสบการณ์การเล่นเกมที่ดีขึ้นมาให้คุณ",
    "backShortly": "เราจะกลับมาในไม่ช้า..."
  },
  "vi": {
    "maintenance": "Bảo trì theo lịch",
    "infoText": "Hiện tại chúng tôi đang nâng cấp nhằm mang lại cho bạn trải nghiệm chơi game tốt hơn.",
    "backShortly": "Chúng tôi sẽ sớm trở lại..."
  },
  "ja": {
    "maintenance": "定期メンテナンス！",
    "infoText": "現在、より良いゲーム体験を提供するためにアップグレードを行っています。",
    "backShortly": "しばらくお待ちください…"
  },
  "ko": {
    "maintenance": "정기 유지보수 중입니다",
    "infoText": "보다 쾌적하게 게임을 즐기시도록 업그레이드 중입니다.",
    "backShortly": "잠시 기다려 주십시오…"
  },
  "id": {
    "maintenance": "Pemeliharaan terjadwal",
    "infoText": "Kami sedang melakukan peningkatan untuk hadirkan pengalaman bermain game yang lebih baik untuk Anda.",
    "backShortly": "Kami akan segera kembali..."
  },
  "ms": {
    "maintenance": "Penyelenggaraan terjadual",
    "infoText": "Kami sedang menjalankan naik taraf untuk membawa pengalaman permainan yang lebih baik untuk anda.",
    "backShortly": "Kami akan kembali sebentar lagi..."
  },
  "lv": {
    "maintenance": "Plānotie tehniskie darbi",
    "infoText": "Pašlaik veicam uzlabojumus labākai spēļu pieredzei.",
    "backShortly": "Drīzumā atgriezīsimies..."
  },
  "lt": {
    "maintenance": "Planinė priežiūra",
    "infoText": "Šiuo metu atsinaujiname, kad užtikrintume geresnę žaidimų patirtį.",
    "backShortly": "Netrukus grįšime..."
  },
  "da": {
    "maintenance": "Planlagt vedligeholdelse",
    "infoText": "Vi opgraderer i øjeblikket for at give dig en bedre spilleoplevelse.",
    "backShortly": "Vi vender tilbage snarest..."
  },
  "sk": {
    "maintenance": "Plánovaná údržba",
    "infoText": "Momentálne aktualizujeme, aby sme vám priniesli lepší herný zážitok.",
    "backShortly": "Čoskoro sa vrátime ..."
  },
  "cs": {
    "maintenance": "Plánovaná údržba",
    "infoText": "Momentálně aktualizujeme, abychom vám přinesli lepší herní zážitek.",
    "backShortly": "Brzy se vrátíme ..."
  },
  "el": {
    "maintenance": "Προγραμματισμένη συντήρηση",
    "infoText": "Αυτή τη στιγμή πραγματοποιούμε αναβάθμιση για να σας προσφέρουμε καλύτερη εμπειρία παιχνιδιού.",
    "backShortly": "Επιστρέφουμε σύντομα..."
  },
  "nl": {
    "maintenance": "Gepland onderhoud",
    "infoText": "We voeren momenteel een upgrade uit om uw speelervaring nog beter te maken.",
    "backShortly": "We zijn binnenkort terug..."
  },
  "et": {
    "maintenance": "Plaanilised hooldustööd",
    "infoText": "Teeme uuendusi, et pakkuda sulle paremat mänguelamust.",
    "backShortly": "Oleme varsti tagasi..."
  },
  "ro": {
    "maintenance": "Mentenanță planificată",
    "infoText": "Suntem în curs de actualizare pentru a vă îmbunătăți experiența de joc.",
    "backShortly": "Vom reveni în curând..."
  },
  "ru": {
    "maintenance": "Плановое обслуживание",
    "infoText": "В настоящий момент мы производим обновление, чтобы Вам было еще приятнее играть.",
    "backShortly": "Мы скоро вернемся..."
  },
  "hu": {
    "maintenance": "Tervezett karbantartartás",
    "infoText": "Jelenleg fejlesztéseket eszközölünk, hogy jobb játékélményben legyen része.",
    "backShortly": "Hamarosan visszatérünk..."
  },
  "hr": {
    "maintenance": "Planirano održavanje",
    "infoText": "U tijeku je nadogradnja kako bismo vam mogli pružiti bolje iskustvo igranja.",
    "backShortly": "Vraćamo se uskoro..."
  }
};
