#!/bin/bash

PROCESS_NAME="dealermodule"
ENV_TAG="common-multi-dm"
HOSTNAME=$(hostname)

# Count the number of dealermodule processes currently running
# -c counts the number of matching processes
# -f matches against the full argument list
# If pgrep finds nothing, it exits with 1, so we catch that and set count to 0
if ! COUNT=$(pgrep -c -f "$PROCESS_NAME"); then
    COUNT=0
fi

# Print to stdout in Prometheus format
cat <<EOF
# HELP number_of_application_count Current count of running processes for ${PROCESS_NAME}
# TYPE number_of_application_count gauge
number_of_application_count{Env="${ENV_TAG}", hostname="${HOSTNAME}"} ${COUNT}
EOF