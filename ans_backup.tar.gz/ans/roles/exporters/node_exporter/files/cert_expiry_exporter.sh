#!/bin/bash

IP=$(ip route get 1.1.1.1 | awk '{print $7; exit}')
HOSTNAME=$(hostname -s)
CERT_PATH="/home/pplc/certs/dealermodule/${IP}.crt"

METRICS_FILE="/home/docker/node-exporter/data/cert_expiry.prom"

echo "# HELP cert_expiry_days Days until certificate expiry" > "$METRICS_FILE"
echo "# TYPE cert_expiry_days gauge" >> "$METRICS_FILE"

if [ ! -f "$CERT_PATH" ]; then
    echo "cert_expiry_days{hostname=\"$HOSTNAME\", certificate=\"$IP\"} -1" >> "$METRICS_FILE"
    exit 0
fi

expiry_date=$(openssl x509 -in "$CERT_PATH" -noout -enddate | cut -d= -f2)
expiry_epoch=$(date -d "$expiry_date" +%s)
now_epoch=$(date +%s)

days_left=$(( (expiry_epoch - now_epoch) / 86400 ))

echo "cert_expiry_days{hostname=\"$HOSTNAME\", certificate=\"$IP\"} $days_left" >> "$METRICS_FILE"
