#!/bin/bash

set -e

# Function to check if Docker is installed
check_docker_installed() {
    if ! command -v docker; then
        echo "Error: Docker is not installed. Please install Docker before running this script."
        exit 1
    fi
}

# Function to prune stopped containers
prune_containers() {
    if docker container prune -f; then
        echo "Stopped containers pruned successfully."
    else
        echo "Error: Failed to prune stopped containers."
        exit 1
    fi
}


# Function to prune images excluding specified references
prune_images_exclude() {
    local exclude_references=("$@")
    
    # Get a list of image IDs to exclude
    exclude_ids=()
    for reference in "${exclude_references[@]}"; do
	exclude_ids+=($(docker images --format '{{.ID}}\t{{.CreatedAt}}\t{{.Repository}}:{{.Tag}}' --filter=reference=$reference | sort -k2,2 | awk '{print $1}' | tail -n1))
    done

    # Prune images excluding the specified references
    exclude_idn=`echo ${exclude_ids[@]}| sed 's/ /|/g'`
    docker images --quiet | egrep -v "${exclude_idn}" | xargs docker rmi -f
}

check_docker_installed

# Specify the references to exclude
exclude_references=(
    '*/*/gitlab-runner/*'
    '*/*ansible*'
    '*/*/jenkins-job-builder'
    # Add more exclusion references as needed
)

echo "Pruning stopped containers"

prune_containers

echo "Pruning images excluding references: ${exclude_references[@]}"

prune_images_exclude "${exclude_references[@]}"

echo "Image pruning completed successfully."
