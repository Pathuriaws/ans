# Dealermodule deployment

Dealermodule is javafx application and uses X server, thus DISPLAY (and XAUTHORITY?) should be passed properly to the service.
Also, service user should be allowed to connect to X server.

We have 2 deployment types: docker and systemd (java -jar) defined in inventory.

Default is deployment_type=docker, ~~but `sicbo` tables require root permissions to scan /dev/USB devices for specivic vendor.~~

~~That's why deployment_type=jar is used which actually mean systemd service started with root user.~~

Sicbo migrated to docker deployment in [LINF-535](https://pragmaticplay.atlassian.net/browse/LINF-535)
[Implementation details](##passing-permissions-to-scan-/dev)

## Passing DISPLAY and permissions

### docker deployment

Since DM hosts configured to login to X session (gnome) with user `host` automatically it's enough
just pass DISPLAY env (usually ":0") and mount /tmp/.X11-unix socket to the container.
DM process is running in container under same uid `1000` so it already has access to X server.

### systemd service deployment

We use [/etc/Xn.hosts](https://www.x.org/releases/X11R7.7/doc/man/man1/Xserver.1.xhtml#heading10) to allow all local connections
to X server. Another way to use xhost command, e.g. when per user access required.

### systemd service deployment --user scope

<https://wiki.archlinux.org/title/Systemd/User#Writing_user_units>

Similar to systemd but doesn't require to set X permissions.
`jar-deployment-user.yml` not used in favor of system service because of additionaly complexity for --user scope services management

## Passing permissions to scan /dev

Required for Sicbo to identify and use `shaker` device - [getDeviceNshake](https://gitlab.livetechlabs.net/pp-live/dealermodule/-/blob/master/src/main/java/com/extremelivegaming/dmodule/views/games/sicbo/SicBoController.java#L517)

1. Additional system groups `dialout` and `plugdev` passed to docker container to allow scan over `/dev` for USB devices
2. Udev rule added to allow `host` group to open `hidraw` device from vendor `04d8` - requires host reboot after adding.
