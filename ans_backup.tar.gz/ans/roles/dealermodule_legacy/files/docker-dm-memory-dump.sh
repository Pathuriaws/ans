#! /bin/sh -e

docker exec -i dealermodule jcmd 1 GC.heap_dump /opt/app/memory-dump

docker cp dealermodule:/opt/app/memory-dump /home/host/Desktop/
chmod 644 /home/host/Desktop/memory-dump

docker exec -i dealermodule rm memory-dump