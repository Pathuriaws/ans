#!/bin/sh -e

DATESTAMP=`date +%Y-%m-%d-%H-%M-%S`

docker exec -it dealermodule /bin/sh -c '$JAVA_HOME/bin/jstack -l 1' > ~/Desktop/dm-threads-dump.${DATESTAMP}.txt
