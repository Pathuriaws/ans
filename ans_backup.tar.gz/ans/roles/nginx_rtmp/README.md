# Nginx RTMP Role

Ansible role for deploying Nginx with RTMP module for live streaming ingestion and HLS/CMAF serving.

## Description

This role deploys a containerized Nginx with RTMP module that:
- Accepts RTMP streams on port 1935
- Serves HLS/CMAF content via HTTP on port 8080
- Provides health check endpoint at `/health`
- Runs as non-root user for security

## Variables

| Variable | Default | Description |
|----------|---------|-------------|
| `nginx_container_name` | `nginx-rtmp` | Container name |
| `nginx_image` | `nginx-rtmp:latest` | Docker image |
| `nginx_config_dir` | `/opt/nginx/config` | Config directory on host |
| `nginx_hls_dir` | `/home/administrator/pm2ffmpeg/hls` | HLS output directory |
| `nginx_temp_dir` | `/home/administrator/pm2ffmpeg/nginx_temp` | Temp directory |
| `nginx_worker_processes` | `auto` | Nginx worker processes |
| `nginx_worker_connections` | `8192` | Worker connections |
| `nginx_keepalive_timeout` | `15` | Keepalive timeout |
| `nginx_uid` | `1001` | Container user ID |
| `nginx_gid` | `1001` | Container group ID |

## Usage

### Run playbook

```bash
# Check mode (dry run)
ansible-playbook -i ./streams/inventory/encoder/rohosts service_nginx_rtmp.yml -u <user-name> --limit 192.168.39.227 --check

# Deploy to specific host
ansible-playbook -i ./streams/inventory/encoder/rohosts service_nginx_rtmp.yml -u <user-name> --limit 192.168.39.227
```

## Endpoints

- **RTMP Ingest**: `rtmp://host:1935/live`
- **HLS Content**: `http://host:8080/hls/`
- **Health Check**: `http://host:8080/health`