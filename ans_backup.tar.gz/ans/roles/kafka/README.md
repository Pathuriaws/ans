# script for gen ssl - utils/generate-docker-kafka-ssl-certs

## examples

<https://github.com/tulios/kafkajs/blob/master/docker-compose.1_1.yml>

<https://developer.ibm.com/components/kafka/tutorials/kafka-authn-authz/>
