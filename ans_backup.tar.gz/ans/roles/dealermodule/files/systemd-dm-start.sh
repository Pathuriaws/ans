#!/bin/sh

sudo systemctl start dealermodule
sudo systemctl status dealermodule --no-pager -l
