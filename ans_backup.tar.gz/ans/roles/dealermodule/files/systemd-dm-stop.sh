#!/bin/sh

sudo systemctl stop dealermodule
sudo systemctl status dealermodule --no-pager -l
