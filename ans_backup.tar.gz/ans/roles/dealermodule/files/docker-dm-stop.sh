#!/bin/sh -e

docker stop dealermodule
