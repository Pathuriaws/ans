#!/bin/bash -e

JAVA_HOME=`dirname $(dirname $(readlink -f $(which javac)))`
DATESTAMP=`date +%Y-%m-%d-%H-%M-%S`

dmpid=`sudo systemctl show -p MainPID --value dealermodule`
sudo $JAVA_HOME/bin/jstack -l ${dmpid} > ~/Desktop/dm-threads-dump-${DATESTAMP}.txt
