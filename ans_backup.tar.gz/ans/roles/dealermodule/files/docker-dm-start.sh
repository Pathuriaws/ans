#!/bin/sh -e

docker start dealermodule
