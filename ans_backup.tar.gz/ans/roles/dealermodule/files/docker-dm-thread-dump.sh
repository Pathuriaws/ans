#!/bin/sh -e

docker exec -i dealermodule /bin/sh -c '/usr/lib/java/jdk1.8.0_221/bin/jstack -l 1' > ~/Desktop/dm-threads-dump.$(date +%Y-%m-%d-%H-%M-%S).txt
