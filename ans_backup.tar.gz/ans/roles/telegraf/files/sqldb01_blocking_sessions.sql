select 
  count(*) AS blocked_session_count,
  ISNULL(sum(wait_time),0) AS blocked_waittime_total_ms
from sys.dm_exec_requests
where blocking_session_id > 0