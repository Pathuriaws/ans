Role Name
=========

Ansible role to install and configure Eclipse Jetty Web Server (Version 12).

Requirements
------------

This role requires a Debian-based system (e.g., Ubuntu).
It will attempt to install `openjdk-17-jdk-headless` as a prerequisite.
However, it is currently configured to use a specific Java 21 binary path (`/usr/lib/jvm/jdk-21.0.8/bin/java`) by default. Ensure this path exists or override `jetty_java_bin`.

Role Variables
--------------

The following variables are defined in `defaults/main.yml`:

| Variable | Default Value | Description |
|----------|---------------|-------------|
| `jetty_version` | `12.1.5` | The version of Jetty to download and install. |
| `jetty_user` | `jetty` | System user to run the Jetty service. |
| `jetty_group` | `jetty` | System group for the Jetty service. |
| `jetty_home_parent` | `/home/{{ jetty_user }}` | Base directory for Jetty installation. |
| `jetty_home` | `.../jetty-home` | Path to the Jetty distribution (binaries). |
| `jetty_base` | `.../game-server` | Path to the Jetty configuration base. |
| `jetty_java_bin` | `/usr/lib/jvm/jdk-21.0.8/bin/java` | Full path to the Java executable used to run Jetty. |
| `jetty_port` | `7001` | The HTTP port Jetty will listen on. |

Dependencies
------------

None.

Example Playbook
----------------

    - hosts: game_servers
      roles:
         - role: jetty
           vars:
             jetty_version: "12.0.8"
             jetty_port: 8080
             jetty_java_bin: "/usr/bin/java"

License
-------

BSD

Author Information
------------------

Arrise
