import re
import sys
import os

def process_all_changes(file_path, joined_diff):
    # Split the joined diff string from Ansible into individual lines
    raw_changes = [c.strip() for c in joined_diff.split('---LINE---') if c.strip()]
    
    adds = {}
    deletes = set()

    for change in raw_changes:
        # Determine if it's an Add (-) or Delete (+)
        is_add = True if change.startswith("-") else False
        
        # Remove prefix and normalize '=' to ': ' for YAML
        clean = re.sub(r'^[+-]', '', change).replace("=", ": ", 1).strip()
        
        # Format Booleans: replace 'true' with ''true'' using word boundaries
        clean = re.sub(r'\btrue\b', "'true'", clean, flags=re.IGNORECASE)
        clean = re.sub(r'\bfalse\b', "'false'", clean, flags=re.IGNORECASE)
        
        # Clean up any potential double-quoting if already present
        clean = clean.replace("''true''", "'true'").replace("''false''", "'false'")
            
        key = clean.split(": ")[0].strip()
        
        if is_add:
            adds[key] = clean
        else:
            deletes.add(key)

    # CONFLICT RESOLUTION: If a key is in both Adds and Deletes, the Add wins.
    for key in list(deletes):
        if key in adds:
            deletes.remove(key)

    lines = []
    if os.path.exists(file_path):
        with open(file_path, 'r') as f:
            lines = [l.strip() for l in f.readlines() if l.strip()]

    new_content = []
    processed_keys = set()

    for line in lines:
        if ":" in line:
            current_key = line.split(":")[0].strip()
            if current_key in adds:
                new_content.append(adds[current_key])
                processed_keys.add(current_key)
            elif current_key in deletes:
                processed_keys.add(current_key)
                continue 
            else:
                new_content.append(line)
        else:
            # Keep comments or empty lines
            new_content.append(line)

    for key, value in adds.items():
        if key not in processed_keys:
            new_content.append(value)

    with open(file_path, 'w') as f:
        for item in new_content:
            f.write(item + "\n")

if __name__ == "__main__":
    if len(sys.argv) > 2:
        target_file = sys.argv[1]
        diff_data = sys.argv[2]
        process_all_changes(target_file, diff_data)