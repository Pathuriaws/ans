#!/usr/bin/env python2
# Spizzheno and modified https://github.com/jsmartin/nagios-docker/blob/master/check_docker
import argparse
import nagiosplugin
import json
import docker

class Docker(nagiosplugin.Resource):

    def __init__(self, url):
        self.url = url

    def probe(self):
        '''Checks docker stats.
        '''

        conn = docker.from_env()

        # try to connect the docker service, and catch an exception if we
        # can't.
        try:
            docker_info = conn.info()
            self.docker_running = 0
        except:
            self.docker_running = 1

        if self.docker_running == 0:
            self.containers_running = docker_info['ContainersRunning']
            self.containers_restarting = len(conn.containers.list(all=True,
                                                             filters={'status': 'restarting'}))

            metrics = [
                nagiosplugin.Metric('service', self.docker_running),
                nagiosplugin.Metric('running', self.containers_running),
                nagiosplugin.Metric('restarting', self.containers_restarting)
            ]

        else:
            metrics = [nagiosplugin.Metric('service', self.docker_running)]

        return metrics


@nagiosplugin.guarded
def main():
    argp = argparse.ArgumentParser()
    argp.add_argument('-u', '--url', metavar='URL',
                      help='URL string for Docker service.',
                      default='unix://var/run/docker.sock')
    args = argp.parse_args()
    check = nagiosplugin.Check(Docker(args.url),
                               nagiosplugin.ScalarContext('service', '0', '0'),
                               nagiosplugin.ScalarContext('running', '100', '200'),
                               nagiosplugin.ScalarContext('restarting', '0', '0'))
    check.main()


if __name__ == '__main__':
    main()
