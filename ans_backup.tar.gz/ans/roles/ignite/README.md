# Check ignite is working

```sh
docker run -it --name=ignite-client --rm -v /home/docker/ignite/config/client-config.xml:/client-config.xml apacheignite/ignite:2.8.1 apache-ignite/bin/ignitevisorcmd.sh
open -cpath=/client-config.xml
top
```
