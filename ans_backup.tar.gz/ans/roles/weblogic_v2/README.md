# Weblogic domains setup v2

Based on ansible `include_vars` `weblogic_app_name`

## Apply only systemd service change over casino, casino2

```sh
ansible-playbook -i inventory/devint weblogic.yml -D -t weblogic-systemd-service -e weblogic_app_name=backoffice
```
