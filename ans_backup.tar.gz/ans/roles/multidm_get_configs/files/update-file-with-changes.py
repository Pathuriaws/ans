import sys
import re
from pathlib import Path

# Replace old_line with new_line in file
def replace_line_in_file(file_to_update, line_to_process):

    if not should_update_hostfile(line_to_process):
        return

    # Get the key of the property
    property_key = line_to_process.split(": ")[0]

    with open(file_to_update, 'r') as file:
        lines = file.readlines()

    new_content = []
    # Replace with new line if property key matches else add new line entry
    if to_add:
        property_key_exists = False
        for line in lines:
            line_key = line.split(": ")[0]
            if property_key == line_key:
                new_content.append(line_to_process + "\n")
                property_key_exists = True
            else:
                new_content.append(line)

        if not property_key_exists:
            new_content.append(line_to_process + "\n")
    # Remove lines
    else:
        for line in lines:
            if line_to_process in line:
                continue
            new_content.append(line)

    with open(file_to_update, 'w') as file:
        file.writelines(new_content)

# Decide if we should update the hostfile
def should_update_hostfile(line_to_process):
    full_file_path = Path(sys.argv[1])
    stage = sys.argv[1].split("/")[-3]

    game_type_defaults = full_file_path.parent / "defaults.yml"
    env_defaults = full_file_path.parent.parent / f"{stage}_defaults.yml"
    global_defaults = full_file_path.parent.parent.parent / "global_defaults.yml"

    with open(game_type_defaults, "r") as f:
        print(f"Checking property in game type defaults: {game_type_defaults}")
        lines = f.readlines()
        print(lines)
        if line_to_process in [line.strip() for line in lines]:
            return False

    with open(env_defaults, "r") as f:
        print(f"Checking property in env defaults: {env_defaults}")
        lines = f.readlines()
        print(lines)
        if line_to_process in [line.strip() for line in lines]:
            return False

    with open(global_defaults, "r") as f:
        print(f"Checking property in global defaults: {global_defaults}")
        lines = f.readlines()
        print(lines)
        if line_to_process in [line.strip() for line in lines]:
            return False

    return True

if __name__ == "__main__":
    # Get command line arguments
    file_to_update = sys.argv[1]
    line_to_process = sys.argv[2] if len(sys.argv) > 2 else ""

    # Determine if we have to add or remove the property
    to_add = True if line_to_process.startswith("-") else False

    # Sanitization
    # Remove + or - from the line and replace the first "=" with ":"
    line_to_process = re.sub(r'^[+-]', '', line_to_process).replace("=", ": ", 1)

    # Replace "true" and "false" with "'true'" and "'false'"
    if "true" in line_to_process and "'true'" not in line_to_process:
        line_to_process = line_to_process.replace("true", "'true'")
    if "false" in line_to_process and "'false'" not in line_to_process:
        line_to_process = line_to_process.replace("false", "'false'")

    replace_line_in_file(file_to_update, line_to_process)
