#! /bin/bash
# RUN SNAP
cd $1
echo ........... Connected from : - $1
mkdir -p /home/weblogic/deployments/frontend/desktop/assets/snaps/$2/ && cp -ar * /home/weblogic/deployments/frontend/desktop/assets/snaps/$2/
echo ..files copied to /home/weblogic/deployments/frontend/desktop/assets/snaps/$2/
