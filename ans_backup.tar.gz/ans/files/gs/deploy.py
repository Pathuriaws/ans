"""
This script is some reworked copy from https://stackoverflow.com/questions/21899565/bea-050001-wlcontext-close-was-called-in-a-different-thread-than-the-one-in
Oracle weblogic libs somehow imported via wlst.sh to use funtions connect(), disconnect() and others
"""

import getopt
import re
import sys

username = ''
password = ''
deploymentFile = ''
applicationName = ''
wlPort = ''
task = ''

def usage():
    print('Usage:')
    print('/bea/oracle_common/common/bin/wlst.sh /home/weblogic/deploy.py -u username -p password -w wlPort -a applicationName -f deploymentFile -t task')
    sys.exit(2)

# connect to domain admin
def connectAdmin():
    try:
        connect(username, password,'t3://localhost:' + wlPort )
        print('Successfully connected')
    except:
        print('Unable to connect t3://localhost:' + wlPort )
        sys.exit(0)

# stop and undeploy app
def undeployApp():
    try:
        stopApplication(applicationName)
        undeploy(applicationName,timeout=60000)
    except:
        print('Error undeploy or stop app')
        # sys.exit(1)

def deployApp():
    try:
        deploy(applicationName, deploymentFile ,upload='true')
    except:
        print('Error deploy app')
        exit()
        sys.exit(1)

def DeployMain():
    appList = re.findall(applicationName, ls('/AppDeployments'))
    if len(appList) >= 1:
        print('Found application')
        print('Firstly need undeploy app')
        undeployApp()
        print('Undeploy is successfull')
        deployApp()
    else:
        print('Application didn\'t find')
        deployApp()

if __name__=='__main__' or __name__== 'main':
    try:
        opts, args = getopt.getopt(sys.argv[1:], 'u:p:w:a:f:t:', ['username=', 'password=', 'wlPort=', 'applicationName=', 'deploymentFile=', 'task='])
    except getopt.GetoptError, err:
        print str(err)
        usage()

for opt, arg in opts:
    if opt in '-u':
        username = arg
    elif opt in '-p':
        password = arg
    elif opt in '-w':
        wlPort = arg
    elif opt in '-a':
        applicationName = arg
    elif opt in '-f':
        deploymentFile = arg
    elif opt in '-t':
        task = arg

if username == '':
    print('Missing -u username')
    usage()
elif password == '':
    print("Missing -p password")
    usage()
elif wlPort == '':
    print("Missing -w wlPort")
    usage()
elif applicationName == '':
    print("Missing -a applicationName")
    usage()
elif deploymentFile == '':
    print('Missing -f deploymentFile')
    usage()
elif task == '':
    print('Missing -t task')
    usage()


connectAdmin()
if task == 'undeploy':
    undeployApp()
elif task == 'deploy':
    DeployMain()
disconnect()
exit()
