#!/bin/bash

# Configuration
LOG_FILE="/var/log/promo_api_monitor.log"
CAMPAIGN_DETAILS_API_URL="http://promo.prelive0.internal/api/internal/live-machine/live-casino/liveMachine00001"
WEBHOOK_URL="https://default214f6519cd194726a221b70378e889.f6.environment.api.powerplatform.com:443/powerautomate/automations/direct/workflows/8dac5d3609224cc3b172a0c98c9bfb74/triggers/manual/paths/invoke?api-version=1&sp=%2Ftriggers%2Fmanual%2Frun&sv=1.0&sig=LPrJ8e2O4j2YWQqyrM11RHcrxNisPHxnHhw-V-E9quo"
S3_URI="s3://pplive-internal/flutter-livemachine-campaign/playerIds.csv"
LOCAL_FILE_PATH="/tmp/playerIds.csv"
AUTH_API_URL="http://promo.prelive0.internal/api/bcpToken"


# Fetch Campaign details via API
CAMPAIGN_DETAILS_RESPONSE=$(curl -sf "$CAMPAIGN_DETAILS_API_URL")
if [ $? -ne 0 ]; then
    echo "$(date -u): Error: API unreachable." >> "$LOG_FILE"
    exit 1
fi

# Extract startDateTime using jq [Target format: 2026-02-16T08:55:38Z]
START_DT=$(echo "$CAMPAIGN_DETAILS_RESPONSE" | jq -r '.data.startDateTime')

if [[ "$START_DT" != "null" && -n "$START_DT" ]]; then
    TARGET_TIME=$(date -u -d "$START_DT" +%s)
    CURRENT_TIME=$(date -u +%s)

    WINDOW_START=$((TARGET_TIME - 600))
    WINDOW_END=$((TARGET_TIME - 300))

    FORMATTED_DT=$(date -u -d "$START_DT")
    ALERT_TRIGGER_DT=$(date -u)

    if [ "$CURRENT_TIME" -ge "$WINDOW_START" ] && [ "$CURRENT_TIME" -le "$WINDOW_END" ]; then
        curl -s -X POST "$WEBHOOK_URL" \
             -H "Content-Type: application/json" \
             -d "{
                \"event\": \"LiveMachine Campaign\",
                \"webhook_trigger_datetime\": \"$ALERT_TRIGGER_DT\",
                \"event_start_dateime\": \"$FORMATTED_DT\"
             }"
             
        echo "$ALERT_TRIGGER_DT: Alert sent for $START_DT" >> "$LOG_FILE"
    fi
fi


# Send Player IDs List to Promo API
CAMPAIGN_ID=$(echo "$CAMPAIGN_DETAILS_RESPONSE" | jq -r '.data.campaignId')
CAMPAIGN_STATUS=$(echo "$CAMPAIGN_DETAILS_RESPONSE" | jq -r '.data.status')
CAMPAIGN_PLAYERS_COUNT=$(echo "$CAMPAIGN_DETAILS_RESPONSE" | jq -r '.data.players | length')

CSV_UPLOAD_API_URL="http://promo.prelive0.internal/api/internal/live-machine/upload-csv?liveMachineId=$CAMPAIGN_ID"
CAMPAIGN_UPDATE_API_URL="http://promo.prelive0.internal/api/internal/live-machine/update/$CAMPAIGN_ID"

if [[ "$CAMPAIGN_STATUS" == "PENDING" && "$CAMPAIGN_PLAYERS_COUNT" -eq 0 ]]; then
    LOCK_FILE="/tmp/s3_upload.lock"
    SHOULD_UPLOAD=false

    if [ ! -f "$LOCK_FILE" ]; then
        # No lock exists, safe to upload
        SHOULD_UPLOAD=true
    else
        # Check if lock is older than 5 minutes (300 seconds)
        LAST_MOD=$(stat -c %Y "$LOCK_FILE")
        CURRENT_TIME=$(date +%s)
        DIFF=$((CURRENT_TIME - LAST_MOD))

        if [ "$DIFF" -ge 300 ]; then
            SHOULD_UPLOAD=true
        fi
    fi

    if [ "$SHOULD_UPLOAD" = true ]; then
        echo "$(date -u): Status pending/empty list. Fetching Auth Token..." >> "$LOG_FILE"

        # A. Fetch the Bearer Token
        TOKEN=$(curl -sf -X GET "$AUTH_API_URL")

        if [[ -z "$TOKEN" ]]; then
            echo "$(date -u): Error: Failed to retrieve Auth Token." >> "$LOG_FILE"
            exit 1
        fi

        # B. Download from S3
        aws s3 cp "$S3_URI" "$LOCAL_FILE_PATH" --quiet

        if [ $? -eq 0 ]; then
            # C. Upload with the Dynamic Token
            UPLOAD_RESPONSE=$(curl -X POST "$CSV_UPLOAD_API_URL" \
                                --header 'accept: */*' \
                                --header "Authorization: Bearer $TOKEN" \
                                --form "file=@$LOCAL_FILE_PATH" \
                                -sf)

            if [ $? -eq 0 ] && [ -n "$UPLOAD_RESPONSE" ]; then
                # D. Extract status and upload_id
                UPLOAD_STATUS=$(echo "$UPLOAD_RESPONSE" | jq -r '.status')
                FILE_UPLOAD_ID=$(echo "$UPLOAD_RESPONSE" | jq -r '.data.fileUploadId')

                if [[ "$UPLOAD_STATUS" == "SUCCESS" && -n "$FILE_UPLOAD_ID" ]]; then
                    # E. Call the Third (Confirmation) API using the extracted ID
                    curl -sf -X POST "$CAMPAIGN_UPDATE_API_URL" \
                        --header 'accept: */*' \
                        --header 'Content-Type: application/json' \
                        --header "Authorization: Bearer $TOKEN" \
                        --data "{
                            \"currency\": \"GBP\",
                            \"levels\": [
                                {
                                    \"levelId\": 1,
                                    \"prizeType\": \"FREE_CHIPS\",
                                    \"prizeValue\": 10
                                },
                                {
                                    \"levelId\": 2,
                                    \"prizeType\": \"FREE_CHIPS\",
                                    \"prizeValue\": 3
                                },
                                {
                                    \"levelId\": 3,
                                    \"prizeType\": \"FREE_SPINS\",
                                    \"prizeValue\": 1
                                },
                                {
                                    \"levelId\": 4,
                                    \"prizeType\": \"CASH\",
                                    \"prizeValue\": 100
                                },
                                {
                                    \"levelId\": 5,
                                    \"prizeType\": \"CASH\",
                                    \"prizeValue\": 190
                                },
                                {
                                    \"levelId\": 6,
                                    \"prizeType\": \"CASH\",
                                    \"prizeValue\": 200
                                }
                            ],
                            \"jackpots\": [ 5000, 10000, 25000 ],
                            \"uploadId\": \"$FILE_UPLOAD_ID\"
                        }"

                    if [ $? -eq 0 ]; then
                        echo "$(date -u): Success: File ID $FILE_UPLOAD_ID confirmed." >> "$LOG_FILE"
                        touch "$LOCK_FILE"
                        rm -f "$LOCAL_FILE_PATH"
                    else
                        echo "$(date -u): Error: Confirmation failed for ID $FILE_UPLOAD_ID" >> "$LOG_FILE"
                    fi
                else
                    echo "$(date -u): Error: Upload API returned status: $UPLOAD_STATUS" >> "$LOG_FILE"
                fi
            else
                echo "$(date -u): Error: Upload failed or returned empty response." >> "$LOG_FILE"
            fi
        else
            echo "$(date -u): Error: S3 download failed." >> "$LOG_FILE"
        fi
    fi
fi
