#!/bin/bash

set -e

echo "Downloading Gitleaks..."
curl -sL https://github.com/gitleaks/gitleaks/releases/download/v8.17.0/gitleaks_8.17.0_linux_x64.tar.gz | tar -xz -C . gitleaks

git config --global --add safe.directory "$CI_PROJECT_DIR"
git checkout "$CI_COMMIT_SHA"

chmod +x ./gitleaks

echo ""
echo "Running Gitleaks scan with default rules..."

./gitleaks detect \
  --source . \
  --report-format json \
  --report-path gitleaks-report.json \
  --log-level error || true

echo ""
echo "---- TOTAL LEAKS FOUND ----"
total=$(jq length gitleaks-report.json)
echo "Total leaks: $total"

echo ""
echo "---- LEAK DETAILS WITH BRANCHES (LOCAL + REMOTE) ----"
leaks=$(jq -c '.[]' gitleaks-report.json)

if [ -z "$leaks" ]; then
  echo "(No leaks found)"
else
  echo "$leaks" | while read -r leak; do
    file=$(echo "$leak" | jq -r '.File')
    line=$(echo "$leak" | jq -r '.StartLine')
    commit=$(echo "$leak" | jq -r '.Commit')

    echo ""
    echo "- File: $file"
    echo "  Line: $line"
    echo "  Commit: $commit"

    branches=$(git branch -a --contains "$commit" | sed 's/^[ *]*//' | sort -u)
    branch_count=$(echo "$branches" | wc -l)
    echo "  Branches ($branch_count):"
    echo "$branches" | sed 's/^/    - /'
  done
fi
