#!/bin/bash

BASE_DIR="/var/lib/docker/volumes"

# 5 largest cache directories
TOP_DIRS=$(du -h -d 1 "$BASE_DIR" 2>/dev/null | sort -rh | head -n 6 | awk '{print $2}' | grep -v "^$BASE_DIR$")

for dir in $TOP_DIRS; do
    DATA_DIR="$dir/_data"
    if [ -d "$DATA_DIR" ]; then
        echo "Cleaning directory: $DATA_DIR"
        rm -rf "${DATA_DIR:?}"/*
    else
        echo "Directory $DATA_DIR does not exist, skipping."
    fi
done
