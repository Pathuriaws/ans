#!/usr/bin/env python3

import json
import argparse
import re
from collections import defaultdict
from datetime import datetime
TOTAL_PORTS_PER_IP = 28
TOTAL_HOST_CAPACITY = 28
POSSIBLE_PORTS = set(str(8002 + i) for i in range(TOTAL_PORTS_PER_IP))


def load_json(path):
    with open(path, 'r') as f:
        return json.load(f)

def extract_valid_streams(gameshows):
    return set(entry['streamName'] for entry in gameshows)

def extract_stream_and_port(proc):
    """
    Safe extraction of stream and port.
    Returns None for port if a valid four/five digit port is not found.
    """
    if not isinstance(proc, dict):
        return None, None

    env = proc.get("pm2_env", {})

    if not isinstance(env, dict):
        args = []
    else:
        args = env.get("args") or []

    name = proc.get("name", "")

    stream = name if re.match(r'^[\w\-.]+$', name) else None
    port = next((arg for arg in args if re.match(r'^\d{4,5}$', arg)), None) 

    return stream, port

def parse_hosts(data, valid_streams):
    """
    Extract hosts → streams and hosts → ports mappings.
    ip_port_map contains ALL detected ports (U).
    """
    ip_stream_map = defaultdict(list)
    ip_port_map = defaultdict(set) 

    for host in data:
        ip = host.get("external_ip")
        if not ip:
            continue

        for proc in host.get("processes", []):
            if not isinstance(proc, dict):
                continue

            stream, port = extract_stream_and_port(proc)

            if port:
                ip_port_map[ip].add(port)

            if stream and stream in valid_streams:
                ip_stream_map[ip].append((stream, port))

        if ip not in ip_stream_map:
            ip_stream_map[ip] = []

    return ip_stream_map, ip_port_map


def format_streams_table(ip, streams):
    lines = [f"- {ip} ({len(streams)} stream{'s' if len(streams) != 1 else ''})"]
    for stream, port in streams:
        lines.append(f"  • {stream} (port: {port})")
    return "\n".join(lines)

def format_alert_block(summary, label, limit):
    lines = []
    if summary["over_limit"]:
        lines.append(f"⚠ {label} ALERT — Overutilized IPs (Limit: {limit})\n")
        for ip, streams in summary["over_limit"]:
            lines.append(format_streams_table(ip, streams))
            lines.append("")  
    return "\n".join(lines).strip()


def format_debug_block(summary, label):
    lines = []
    
    if summary["low_util"]:
        lines.append(f"\n[INFO] {label} Low Utilized Hosts:")
        for ip, streams in summary["low_util"]:
            joined = ", ".join(f"{s}({p})" for s, p in streams)
            lines.append(f"• {ip} → {joined}")

    if summary["no_streams"]:
        lines.append(f"\n[INFO] {label} Hosts With No Gameshows:")
        for ip in summary["no_streams"]:
            lines.append(f"• {ip}")

    if summary["empty_ports"]:
        lines.append(f"\n[INFO] {label} Hosts With Empty Ports:")
        for ip, authoritative_count, unused_ports_set in summary["empty_ports"]:
            
            sorted_ports = sorted(unused_ports_set)
            display_ports_list = sorted_ports[:authoritative_count]
            
            display_ports = ', '.join(display_ports_list)
            
            lines.append(f"• {ip} → {authoritative_count} ports unused: {display_ports}")

    return "\n".join(lines)

def build_summary(ip_streams, ip_ports, label, limit):
    global POSSIBLE_PORTS
    global TOTAL_HOST_CAPACITY
    
    over_limit, low_util, no_streams, empty_ports = [], [], [], []
    
    MBR_CONTROL_STREAMS = {"mbr-control-api", "mbr-monitor", "pm2-logrotate"}
    CDN_CONTROL_STREAMS = {"cdn-monitor", "AUTHCLIENT", "AUTHCLIENT-CACHEOWNER", "cdn-health-check", "pm2-logrotate"}

    for ip in sorted(ip_streams):
        streams = ip_streams[ip]
        
        if label == "MBR":
            filtered_streams = [(s, p) for s, p in streams if s not in MBR_CONTROL_STREAMS]
        elif label == "CDN":
            filtered_streams = [(s, p) for s, p in streams if s not in CDN_CONTROL_STREAMS]
        else:
            filtered_streams = streams
            
        unique = sorted(set(filtered_streams))
        count = len(unique)
        if count == 0:
            no_streams.append(ip)
        elif label == "CDN" and count == 1:
            low_util.append((ip, unique))
        elif label == "MBR" and count in [1, 2]:
            low_util.append((ip, unique))
        elif count > limit:
            over_limit.append((ip, unique))

        used_ports = ip_ports.get(ip, set()) 

        unused_ports_count = TOTAL_HOST_CAPACITY - len(used_ports)
        
        unused_ports_set = POSSIBLE_PORTS - used_ports
        
        if unused_ports_count > 0: 
            empty_ports.append((ip, unused_ports_count, unused_ports_set)) 

    return {
        "over_limit": over_limit,
        "low_util": low_util,
        "no_streams": no_streams,
        "empty_ports": empty_ports
    }

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--gameshow-file', required=True)
    parser.add_argument('--cdn-file', required=True)
    parser.add_argument('--mbr-file', required=True)
    parser.add_argument('--debug', action='store_true')
    args = parser.parse_args()

    gameshows = load_json(args.gameshow_file)
    cdn_data = load_json(args.cdn_file)
    mbr_data = load_json(args.mbr_file)

    valid_streams = extract_valid_streams(gameshows)
    cdn_streams, cdn_ports = parse_hosts(cdn_data, valid_streams)
    mbr_streams, mbr_ports = parse_hosts(mbr_data, valid_streams)

    cdn_summary = build_summary(cdn_streams, cdn_ports, "CDN", limit=2)
    mbr_summary = build_summary(mbr_streams, mbr_ports, "MBR", limit=3)

    alert_output = []
    alert_output.append(format_alert_block(cdn_summary, "CDN", 2)) 
    alert_output.append(format_alert_block(mbr_summary, "MBR", 3))

    final_alert_text = "\n\n".join([b for b in alert_output if b.strip()])

    if final_alert_text.strip():
        with open("alert_output.txt", "w") as f:
            f.write(final_alert_text)

        alert_id = datetime.utcnow().strftime('%Y%m%d-%H%M')

        opsgenie_payload = {
            "message": "Gameshow Mapping Alert",
            "alias": f"GameshowMappingAlert-{alert_id}",
            "description": final_alert_text,
            "priority": "P3"
        }

        with open("alert_payload.json", "w") as f:
            json.dump(opsgenie_payload, f, indent=2)

        print(final_alert_text)
    else:
        print("No alert-worthy content found.")

    if args.debug:
        print("\n--- DEBUG MODE ENABLED ---")
        print(format_debug_block(cdn_summary, "CDN"))
        print(format_debug_block(mbr_summary, "MBR"))
        print("--- END DEBUG ---")

if __name__ == "__main__":
    main()