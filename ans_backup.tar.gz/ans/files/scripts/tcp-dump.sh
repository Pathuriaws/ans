#!/bin/bash

# Define the directory where you want to store the dump files
dump_directory="/home/tcpdump"

if [ ! -d "$dump_directory" ]; then
  # If the directory doesn't exist, create it
  mkdir -p "$dump_directory"
fi

chown tcpdump:tcpdump "$dump_directory"

start_tcpdump() {
    HOSTNAME=$(hostname -s)
    DATE=$(date +%Y%m%d)

    echo "Starting TCP dump with 300MB rotation..."

    /usr/sbin/tcpdump -i any -n -s 96 \
      '(port 80 or port 443 or port 53)' \
      -C 300 \
      -W 20 \
      -w "$dump_directory/tcpdump_${DATE}_${HOSTNAME}.pcap" &
    
    tcpdump_pid=$!
}

# Function to stop the TCP dump
stop_tcpdump() {
    echo "Stopping TCP dump for today..."
    kill -2 "$tcpdump_pid"  # Use SIGINT (2) to stop tcpdump gracefully
    wait "$tcpdump_pid"  # Wait for tcpdump to finish saving the file
}

# Check if a TCP dump is already running for today and stop it
if [ -n "$tcpdump_pid" ]; then
    stop_tcpdump
fi

# check if any stale process are running or stop the current script if any duplicate instance runs

if [ `pgrep -f tcpdump|wc -l` -gt 0 ]; then
    pkill -f tcpdump
fi

# Start the TCP dump for today
start_tcpdump

# Schedule the script to stop at the end of the day (e.g., 11:59 PM)
end_of_day="23:59"

# Calculate the number of seconds until the end of the day
current_time=$(date +"%H:%M")
end_time=$(date -d "$end_of_day" +"%H:%M")
seconds_until_end_of_day=$(( $(date -d "$end_time" +%s) - $(date -d "$current_time" +%s) ))

# Schedule the script to stop using 'at' command
echo "sleep $seconds_until_end_of_day && $0" | sleep $seconds_until_end_of_day

stop_tcpdump

