import yaml
import sys
import os
from tabulate import tabulate

# Path of the YAML file
file_path = 'inventory/stream/group_vars/live'
filename = sys.argv[1]
full_path = os.path.join(file_path, filename)

# Checking if the file exists
if not os.path.isfile(full_path):
    print(f"Error: File '{full_path}' does not exist.")
else:
    # Load YAML data from the file
    with open(full_path, 'r') as file:
        data = yaml.safe_load(file)

    # Initializing dictionaries to store information
    bitrate_info = {}
    distr_info = {}
    bitrate_port_usage = {}
    distr_port_usage = {}

    # Function to add ports to the info dictionary
    def add_ports(info_dict, port_usage_dict, name, ip, ports, stream_name):
        if name not in info_dict:
            info_dict[name] = {
                'ip': ip,
                'ports': set(ports),
                'streams': {stream_name: set(ports)}
            }
        else:
            info_dict[name]['ports'].update(ports)
            if stream_name in info_dict[name]['streams']:
                info_dict[name]['streams'][stream_name].update(ports)
            else:
                info_dict[name]['streams'][stream_name] = set(ports)

        # Track port usage for bitrate or distr
        for port in ports:
            if name not in port_usage_dict:
                port_usage_dict[name] = {}
            if port not in port_usage_dict[name]:
                port_usage_dict[name][port] = []
            port_usage_dict[name][port].append(stream_name)

    # Process each stream
    for stream in data['streams']:
        # Process bitrate
        if 'bitrate' in stream:
            for bitrate in stream['bitrate']:
                bitrate_name = bitrate['name']
                bitrate_ip = bitrate['ext_ip']
                bitrate_port = bitrate['port']
                add_ports(bitrate_info, bitrate_port_usage, bitrate_name, bitrate_ip, [bitrate_port], stream['name'])
        
        # Process distr
        if 'distr' in stream:
            for distr in stream['distr']:
                distr_name = distr['name']
                distr_ip = distr['ext_ip']
                distr_ports = distr['ports']
                add_ports(distr_info, distr_port_usage, distr_name, distr_ip, distr_ports, stream['name'])

    # Prepare data for table and sort it
    bitrate_table = [["Bitrate Name", "IP", "Number of Ports Used", "Ports"]]
    for bitrate_name, info in sorted(bitrate_info.items()):
        port_count = len(info['ports'])
        row = [bitrate_name, info['ip'], port_count, ", ".join(sorted(info['ports']))]
        if port_count < 28:
            row = [f"\033[91m{item}\033[0m" for item in row]  # Red color for rows with less than 28 ports
        bitrate_table.append(row)

    distr_table = [["Distr Name", "IP", "Number of Ports Used", "Ports"]]
    for distr_name, info in sorted(distr_info.items()):
        port_count = len(info['ports'])
        row = [distr_name, info['ip'], port_count, ", ".join(sorted(info['ports']))]
        if port_count < 28:
            row = [f"\033[91m{item}\033[0m" for item in row]  # Red color for rows with less than 28 ports
        distr_table.append(row)

    # Preparing data for same bitrate using same port in other streams
    same_bitrate_table = [["Bitrate Name", "Port", "Streams Using Same Port"]]
    for bitrate_name, ports in bitrate_port_usage.items():
        for port, streams in ports.items():
            if len(streams) > 1:
                same_bitrate_table.append([bitrate_name, port, ", ".join(streams)])

    # Preparing data for same distr using same port in other streams
    same_distr_table = [["Distr Name", "Port", "Streams Using Same Port"]]
    for distr_name, ports in distr_port_usage.items():
        for port, streams in ports.items():
            if len(streams) > 1:
                same_distr_table.append([distr_name, port, ", ".join(streams)])

    # Printing tables using tabulate
    print("Bitrate Information:")
    print(tabulate(bitrate_table, headers="firstrow", tablefmt="grid"))

    print("\nDistr Information:")
    print(tabulate(distr_table, headers="firstrow", tablefmt="grid"))

    print("\nSame Bitrate Using Same Port in Other Streams:")
    print(tabulate(same_bitrate_table, headers="firstrow", tablefmt="grid"))

    print("\nSame Distr Using Same Port in Other Streams:")
    print(tabulate(same_distr_table, headers="firstrow", tablefmt="grid"))
