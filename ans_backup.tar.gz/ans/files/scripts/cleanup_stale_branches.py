import os
import requests
from datetime import datetime, timedelta, timezone
from dateutil.parser import isoparse

def fetch_all_branches(project_id, access_token):
    headers = {"PRIVATE-TOKEN": access_token}
    all_branches = []
    page = 1

    while True:
        url = f"https://gitlab.livetechlabs.net/api/v4/projects/{project_id}/repository/branches?per_page=100&page={page}"
        try:
            response = requests.get(url, headers=headers)
            response.raise_for_status()
        except requests.RequestException as e:
            print(f"[ERROR] Failed to fetch page {page}: {e}")
            break

        page_data = response.json()
        if not page_data:
            break

        all_branches.extend(page_data)
        page += 1

    return all_branches

def list_and_delete_stale_branches():
    access_token = os.getenv("STALE_BRANCH_CLEANUP_TOKEN")
    project_id = os.getenv("PROJECT_ID")
    auto_delete = os.getenv("AUTO_DELETE", "false").strip().lower() in ("true", "1", "yes")

    if not access_token:
        print("[ERROR] Environment variable STALE_BRANCH_CLEANUP_TOKEN is not set.")
        return
    if not project_id:
        print("[ERROR] Environment variable PROJECT_ID is not set.")
        return
    try:
        project_id = int(project_id)
    except ValueError:
        print(f"[ERROR] PROJECT_ID must be an integer. Got: {project_id}")
        return

    excluded_branches = [
        "DO-15457-apt-update",
        "DO-15457",
        "DO-14689-monitoring-process"
    ]

    branches = fetch_all_branches(project_id, access_token)
    print(f"[INFO] Total branches fetched: {len(branches)}")

    stale_cutoff = datetime.now(timezone.utc) - timedelta(days=90)
    stale_branches = []

    for branch in branches:
        if branch.get("protected", True):
            continue
        if branch["name"] in excluded_branches:
            continue

        commit_info = branch.get("commit")
        if not commit_info:
            continue

        committed_date_str = commit_info.get("committed_date")
        if not committed_date_str:
            continue

        try:
            committed_date = isoparse(committed_date_str)
        except Exception as e:
            print(f"[WARNING] Skipping branch '{branch['name']}' due to date parsing error: {e}")
            continue

        if committed_date < stale_cutoff:
            stale_branches.append(branch)

    if not stale_branches:
        print("[INFO] No stale branches older than 90 days (excluding protected and excluded ones).")
        return

    print(f"[INFO] Found {len(stale_branches)} stale branches (older than 90 days):")
    for branch in stale_branches:
        name = branch["name"]
        commit = branch["commit"]
        last_commit = commit.get("committed_date", "N/A")
        author = commit.get("author_name", "Unknown")
        print(f"- {name} (Last commit: {last_commit}, Author: {author})")

    if auto_delete:
        print("[INFO] AUTO_DELETE is enabled. Deleting stale branches...")
        for branch in stale_branches:
            branch_name = branch["name"]
            encoded_name = requests.utils.quote(branch_name, safe='')
            delete_url = f"https://gitlab.livetechlabs.net/api/v4/projects/{project_id}/repository/branches/{encoded_name}"
            try:
                response = requests.delete(delete_url, headers={"PRIVATE-TOKEN": access_token})
                if response.status_code == 204:
                    print(f"[INFO] Deleted: {branch_name}")
                else:
                    print(f"[ERROR] Failed to delete {branch_name}: {response.status_code} - {response.text}")
            except requests.RequestException as e:
                print(f"[ERROR] Request failed while deleting {branch_name}: {e}")
    else:
        print("[INFO] AUTO_DELETE is disabled. No branches were deleted.")

if __name__ == "__main__":
    list_and_delete_stale_branches()
