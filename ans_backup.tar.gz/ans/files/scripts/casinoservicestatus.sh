#!/usr/bin/env bash
# =============================================================================
# casinoservicestatus.sh
#
# Monitors the casino game server on port 7001.
# The game server runs as EITHER:
#   - casino.service        systemd service
#   - casino-gameserver     Docker container
#
# Alert conditions:
#   1. Neither casino.service nor casino-gameserver container is running
#   2. Application endpoint /api/version is not responding
# =============================================================================

set -uo pipefail

SERVICE_NAME="casino"
CONTAINER_NAME="casino-gameserver"
HEALTH_URL="http://127.0.0.1:7001/api/version"

OPS_GENIE_API_KEY="d6136e14-f19e-48ad-9f3b-a5a7beaa1aae"
OPS_GENIE_URL="https://api.opsgenie.com/v2/alerts"

CURL_TIMEOUT=5
LOG_TAG="casino-monitor"

HOST="$(hostname -s)"

log() {
    logger -t "${LOG_TAG}" -- "$*" 2>/dev/null || echo "[$(date -Iseconds)] $*" >&2
}

info() {
    log "INFO  $*"
}

err() {
    log "ERROR $*"
}

send_alert() {
    local message="$1"
    local alias="$2"
    local description="$3"

    local payload
    payload=$(cat <<EOF
{
  "message": "${message}",
  "alias": "${alias}",
  "description": "${description}",
  "responders": [
    {
      "name": "DevOps Team",
      "type": "team"
    }
  ],
  "priority": "P1",
  "tags": ["casino", "gameserver", "${HOST}"]
}
EOF
)

    local http_code
    http_code=$(curl -s -o /dev/null -w "%{http_code}" \
        --max-time 10 \
        -X POST "${OPS_GENIE_URL}" \
        -H "Content-Type: application/json" \
        -H "Authorization: GenieKey ${OPS_GENIE_API_KEY}" \
        -d "${payload}") || true

    if [[ "${http_code}" =~ ^2 ]]; then
        info "OpsGenie alert sent, HTTP ${http_code}: ${message}"
    else
        err "OpsGenie returned HTTP ${http_code} for: ${message}"
    fi
}

main() {
    info "Starting casino game server health check on ${HOST}"

    SERVICE_STATUS="not_found"
    CONTAINER_STATUS="not_found"
    APP_STATUS="unhealthy"
    ACTIVE_MODE="none"

    if command -v systemctl >/dev/null 2>&1; then
        SERVICE_STATUS=$(systemctl is-active "${SERVICE_NAME}" 2>/dev/null || true)

        if [[ -z "${SERVICE_STATUS}" ]]; then
            SERVICE_STATUS="not_found"
        fi
    fi

    if command -v docker >/dev/null 2>&1; then
        CONTAINER_STATUS=$(docker inspect -f '{{.State.Status}}' "${CONTAINER_NAME}" 2>/dev/null || true)

        if [[ -z "${CONTAINER_STATUS}" ]]; then
            CONTAINER_STATUS="not_found"
        fi
    fi

    if [[ "${SERVICE_STATUS}" == "active" ]]; then
        ACTIVE_MODE="casino.service"
    elif [[ "${CONTAINER_STATUS}" == "running" ]]; then
        ACTIVE_MODE="casino-gameserver Docker container"
    else
        ACTIVE_MODE="none"
    fi

    if command -v curl >/dev/null 2>&1; then
        if curl -fsS --max-time "${CURL_TIMEOUT}" "${HEALTH_URL}" >/dev/null 2>&1; then
            APP_STATUS="healthy"
        else
            APP_STATUS="unhealthy"
        fi
    else
        APP_STATUS="curl_not_found"
    fi

    info "service=${SERVICE_STATUS}, container=${CONTAINER_STATUS}, active_mode=${ACTIVE_MODE}, app=${APP_STATUS}"

    if [[ "${SERVICE_STATUS}" != "active" && "${CONTAINER_STATUS}" != "running" ]]; then
        err "No casino deployment is running on ${HOST}"

        send_alert \
            "[${HOST}] P1: Casino game server is DOWN" \
            "casino-gameserver-down-${HOST}" \
            "No casino game server deployment is running on ${HOST}. casino.service status: ${SERVICE_STATUS}. casino-gameserver container status: ${CONTAINER_STATUS}. Application endpoint ${HEALTH_URL} status: ${APP_STATUS}. Please call DevOps Team."

        exit 0
    fi

    if [[ "${APP_STATUS}" != "healthy" ]]; then
        err "Casino API is not responding on ${HOST}. active_mode=${ACTIVE_MODE}"

        send_alert \
            "[${HOST}] P1: Casino game server API is not responding" \
            "casino-gameserver-api-down-${HOST}" \
            "Casino game server process is running via ${ACTIVE_MODE} on ${HOST}, but application endpoint ${HEALTH_URL} is not responding. casino.service status: ${SERVICE_STATUS}. casino-gameserver container status: ${CONTAINER_STATUS}. Please call DevOps Team."

        exit 0
    fi

    info "Casino game server healthy on ${HOST}. active_mode=${ACTIVE_MODE}, app=${APP_STATUS}"
    info "Health check complete"
}

main "$@"