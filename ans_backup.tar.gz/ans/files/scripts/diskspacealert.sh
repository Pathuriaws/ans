#!/bin/sh
hostname=$(hostname)
df -H | grep -vE 'Filesystem|tmpfs|loop*|udev|overlay' | awk '{ print $5 " " $1 }' | while read output;
do
  echo $output
  usep=$(echo $output | awk '{ print $1}' | cut -d'%' -f1  )
  partition=$(echo $output | awk '{ print $2 }' )
  if [ $usep -ge 80 ]; then
    curl -H "Content-Type: application/json" -d "{\"text\": \"$hostname - $partition disc space is less than 20% , please check.\"}" "https://pragmaticplay.webhook.office.com/webhookb2/bcd97275-5852-4884-a2a8-ad40c281b1b8@214f6519-cd19-4726-a221-b70378e889f6/IncomingWebhook/047765e34bf34f7d92250c34c8a60bb3/edcac16d-8ed9-4d38-ada7-85dc2e4e0858/V2jxqhharWKgIEMofwkSRGSmmePkVqM6PATdTyyDRq-lw1"
  fi
done

