import ipaddress
import os
import sys
import yaml
from collections import defaultdict

# ANSI color codes
RED_BACKGROUND = "\033[41m"
GREEN_BACKGROUND = "\033[42m"
BOLD = "\033[1m"
RESET = "\033[0m"

# Removing Commented Line
def strip_inline_comment(line):
    return line.split('#', 1)[0].strip()

# Validating IP Addresses and Ports 
def validate_ip_port(ip_port, line_no):
    if ':' not in ip_port:
        raise ValueError(f"Line {line_no}: Missing ':' in '{ip_port}'")

    ip, port = ip_port.split(':', 1)

    try:
        ipaddress.ip_address(ip)
    except ValueError:
        raise ValueError(f"Line {line_no}: Invalid IP address '{ip}'")

    if not port.isdigit() or not (1 <= int(port) <= 65535):
        raise ValueError(f"Line {line_no}: Invalid port '{port}'")

# Mapping all IPs and Ports with Line Numbers
def get_ip_port_map(filepath):
    with open(filepath, 'r') as f:
        lines = f.readlines()

    try:
        with open(filepath, 'r') as f:
            data = yaml.safe_load(f)
    except yaml.YAMLError as e:
        print(RED_BACKGROUND, BOLD, f"YAML parsing error:\n{e}", RESET)
        sys.exit(1)

    if 'tables_dict' not in data:
        print(RED_BACKGROUND, BOLD, "Missing required 'tables_dict' property in YAML.", RESET)
        sys.exit(1)

    tables_dict = data['tables_dict']
    if not isinstance(tables_dict, dict):
        print(RED_BACKGROUND, BOLD, "'tables_dict' must be a dictionary.", RESET)
        sys.exit(1)

    ip_port_locations = defaultdict(list)

    for lineno, raw_line in enumerate(lines, start=1):
        line = strip_inline_comment(raw_line)
        if ':' not in line or '[' not in line or 'tables_dict' in line:
            continue

        parts = line.split('[')
        if len(parts) < 2:
            continue

        ip_list = parts[1].split(']')[0].split(',')
        for raw_ip in ip_list:
            ip_port = raw_ip.strip().strip('"').strip("'")
            if not ip_port:
                continue
            try:
                validate_ip_port(ip_port, lineno)
                ip_port_locations[ip_port].append(lineno)
            except ValueError as ve:
                print(RED_BACKGROUND, BOLD, f"{ve}", RESET)
                sys.exit(1)

    return ip_port_locations

# Finding Duplicates
def check_duplicates(ip_port_locations):
    has_duplicates = False
    for ip_port, lines in ip_port_locations.items():
        if len(lines) > 1:
            has_duplicates = True
            print(RED_BACKGROUND, BOLD, f"Duplicate found: {ip_port} on lines {', '.join(map(str, lines))}", RESET)
            sys.exit(1)
    if not has_duplicates:
        print(GREEN_BACKGROUND, BOLD, "No duplicate IP:Port combinations found.", RESET)

# Finding Duplicate Streams
def check_duplicate_stream_key(filepath):
    in_tables_dict = False
    keys_seen = {}
    with open(filepath, 'r') as f:
        for lineno, line in enumerate(f, start=1):
            clean_line = strip_inline_comment(line)
            if not clean_line:
                continue  # skip comments and blank lines

            if clean_line.startswith('tables_dict:'):
                in_tables_dict = True
                continue

            if in_tables_dict:
                # Stop if indentation resets (end of tables_dict)
                if not line.startswith(' ') and not line.startswith('\t'):
                    break

                # Check for key (format: key:)
                key_part = clean_line.strip().split(':', 1)
                if len(key_part) >= 2:
                    key = key_part[0].strip()
                    if key in keys_seen:
                        print(RED_BACKGROUND, BOLD, f"Duplicate table key '{key}' found at line {lineno} (previously at line {keys_seen[key]})", RESET)
                        sys.exit(1)
                    else:
                        keys_seen[key] = lineno

# Main
if __name__ == "__main__":
    if len(sys.argv) < 2:
        print(RED_BACKGROUND, BOLD, "Error: Please provide the path to the original YAML file as an argument.", RESET)
        sys.exit(1)

    filePath = "inventory/live/group_vars/" + sys.argv[1]

    if not os.path.isfile(filePath):
        print(RED_BACKGROUND, BOLD, f"Error: File '{filePath}' does not exist.", RESET)
        sys.exit(1)
    
    check_duplicate_stream_key(filePath)
    ip_map = get_ip_port_map(filePath)
    check_duplicates(ip_map)
