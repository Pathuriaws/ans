import re
import os

env = os.getenv("ENVIRONMENT")
studio = os.getenv("STUDIO")

input_file = f"/home/jenkins/agent/workspace/dm-ops/dm-configurations/inventory/{env}/{studio}/hosts"
output_file = "/home/jenkins/agent/workspace/dm-ops/inCaseHosts"

with open(input_file, "r") as fin, open(output_file, "w") as fout:
    for line in fin:
        if ("ansible_host=" in line):
            fout.write(line.lower())
        else:
            fout.write(line)