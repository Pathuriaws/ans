# Migrated from git submodule [inventory](https://gitlab.livetechlabs.net/pplive/infra/inventory)
