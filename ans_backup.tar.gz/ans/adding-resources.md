﻿# New resources provisioning flow

## GS instance provisioning

1. Add new gs instance via `infra/pplive-prod` project
2. Add 2 (on the writting moment) CloudFront distributions for the new gs: gsX.pragmaticplaylive.net and gsX.pplivedealer.com via `infra/pplive-cloudfront` project
3. Apply ansible infra playbooks:
    1. Base ```ansible-playbook -i inventory/${ENV} -l gs${NEW_GS_NUMBER} base.yml -CD -u ubuntu```
    2. Monitoring ```ansible-playbook -i inventory/${ENV} -l gs${NEW_GS_NUMBER} monitoring.yml -CD```
    3. Qualys security agent ```ansible-playbook -i inventory/${ENV} -l gs${NEW_GS_NUMBER} qualys-cloud-agents.yml -CD```
    4. Nginx gs vhost ```ansible-playbook -i inventory/${ENV} -l gs${NEW_GS_NUMBER} service_nginx.yml -CD``` <https://ci2.pragmaticplaylive.net/job/service_nginx-live/>
    5. Setup casino weblogic domain ```ansible-playbook -i inventory/${ENV} -l gs${NEW_GS_NUMBER} weblogic_casino.yml -CD```
4. Deploy current `live` version to the new instance -> check
5. Add new gs to loadbalancer ```ansible-playbook -i inventory/${ENV} -l lb0 service_nginx.yml -CD``` -> check logs
6. Create new GS dashboard with alerts in Grafana

## Add new env

1. Creante new invetory structure in `invetory/` dir (or clone it from any other)
2. Add/update necessary values for new inventory. **Be carefull if inventory cloned: don't forget to change mandatory resources, `stage` at least
3. Add new stage to `.gitlab-ci.yml`
4. Run meta playbook `deploy_platform_infra_services.yml` to deploy all infra services
5. Create/import required databases (SQL, postgresql) or contact to DBA for this task
6. Deploy weblogic domains with `weblogic_all_domains.yml` playbook

## Add new service

### 1. Add service host group inventory

E.g. for static hosts: `service_promo` in inventory/hosts or `service_promo: true` instance tag for AWS envs

### 2. Add playbook and necessary variables (global and per-env if needed)

`service_servicename.yml`

Put all service unique variables to group_vars/all and|or inventory/group_vars

For datasources generate different passwords to avoid some confusions in the future.

#### Request new DB users with required grants via separate Jira tasks, wait for approval

### 3. Monitoring: add filebeat and telegraf service configuration if needed

### 4. Jenkins: add service jobs

* add jobs `deploy-service` and `deploy-service-live`
* add new service parameter for `actionmanager` and `actionmanager-live`
* add new service parameter `get-java-dumps` (for java apps only)

### 5. Test created jobs by running each of them, check result

### 6. Configure monitorin/alerting for the new service/instances
