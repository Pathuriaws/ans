#!/bin/bash

# ------------------------------------------------------------
# Script Name: run_pam_check.sh
# Purpose    : Execute check_pamd_su.yml playbook
# Author     : Rakesh Chetla
# Arguments  :
#   $1 - playbook name
#   $2 - studio
# ------------------------------------------------------------

set -e

if [ "$#" -ne 2 ]; then
    echo "Usage: $0 <playbook_name> <studio>"
    echo "Example: $0 check_pamd_su.yml ro"
    exit 1
fi

PLAYBOOK_NAME="$1"
REGION_INPUT="$2"
CONFIG_FILE="studio_env.conf"

if [ ! -f "$CONFIG_FILE" ]; then
    echo "Config file $CONFIG_FILE not found!"
    exit 1
fi

current_region=""
region_found=false

SUCCESS_COUNT=0
FAIL_COUNT=0

while IFS= read -r line; do

    line=$(echo "$line" | xargs)
    [[ -z "$line" ]] && continue

    if [[ "$line" == *":" ]]; then
        current_region="${line%:}"
        continue
    fi

    if [[ "$current_region" == "$REGION_INPUT" && "$line" == -* ]]; then

        region_found=true
        env=$(echo "$line" | sed 's/- //')

        INVENTORY_PATH="../dm-configurations/inventory/${env}/${REGION_INPUT}"
        LOG_FILE_PATH="/tmp/pam_su_check-${REGION_INPUT}-${env}.log"

        echo "--------------------------------------------------"
        echo "Running for Region: $REGION_INPUT | Environment: $env"
        echo "Inventory: $INVENTORY_PATH"
        echo "Log file: $LOG_FILE_PATH"
        echo "--------------------------------------------------"

        if [ ! -d "$INVENTORY_PATH" ]; then
            echo "Skipping $INVENTORY_PATH (not found)"
            continue
        fi

        echo "Executing: ansible-playbook $PLAYBOOK_NAME -i $INVENTORY_PATH -e log_file=$LOG_FILE_PATH -D"

        # Temporarily disable exit-on-error
        set +e
        ansible-playbook "$PLAYBOOK_NAME" \
            -i "$INVENTORY_PATH" \
            -e "log_file=$LOG_FILE_PATH" \
            -D

        RC=$?
        set -e  # Re-enable strict mode

        if [ $RC -eq 0 ]; then
            echo "✅ SUCCESS for ${env}"
            ((SUCCESS_COUNT++))
        else
            echo "❌ FAILED for ${env} (rc=$RC)"
            ((FAIL_COUNT++))
        fi

    fi

done < "$CONFIG_FILE"

if [ "$region_found" = false ]; then
    echo "Region '$REGION_INPUT' not found in $CONFIG_FILE"
    exit 1
fi

echo "--------------------------------------------------"
echo "Execution Summary for region: $REGION_INPUT"
echo "Successful runs : $SUCCESS_COUNT"
echo "Failed runs     : $FAIL_COUNT"
echo "--------------------------------------------------"

exit 0
