# arrise-ai-services-prod — EKS Cluster GitOps Config Archive

Exported on: 2026-09-03  
Cluster: `arrise-ai-services-prod`  
Region: `eu-west-1`  
Account: `974842793862`  
EKS ARN: `arn:aws:eks:eu-west-1:974842793862:cluster/arrise-ai-services-prod`  
kubectl context: `ai`

---

## Repository Structure

```
arrise-ai-cluster-configs/
├── argocd-apps/          # ArgoCD Application/AppProject manifests + index
├── namespaces/           # One dir per namespace with typed subdirs
│   └── <namespace>/
│       ├── deployments/
│       ├── statefulsets/
│       ├── services/
│       ├── configmaps/
│       ├── ingresses/
│       ├── hpa/
│       ├── pvcs/
│       └── misc/         # daemonsets, serviceaccounts, jobs, cronjobs, pdbs, etc.
│           └── secrets-list.txt   # Secret names only — no values exported
├── helm-values/          # Extracted Helm release values (helm get values)
├── cluster-infra/        # Cluster-scoped: Karpenter, StorageClasses, IngressClasses, PVs
└── README.md
```

---

## Cluster Overview

### Namespace → Purpose → Key Components

| Namespace | Purpose | Key Components | Public URL |
|---|---|---|---|
| `alloy` | Log/metric collection agent | Grafana Alloy DaemonSet | — |
| `argocd` | GitOps CD platform | ArgoCD v3.0.12 (HA Redis, 6 deployments) | argocd.arrise-ai-services-prod.arriselabs.net |
| `arrise-nexus-ai` | Nexus AI backend service | (service accounts only, app likely uses external config) | — |
| `arrise-nexus-ai-web` | Nexus AI web frontend | nginx ingress, 1 deployment | nexusai.arriselabs.net / arrise-nexus-ai-web.arrise-ai-services-prod.arriselabs.net |
| `asana-ui` | Asana integration UI | 1 deployment + ingress | asana-ui.arrise-ai-services-prod.arriselabs.net |
| `central-agent` | Central AI orchestration agent | (namespace with SA only — likely uses ExternalSecrets) | — |
| `cs-telegram-fd-agent` | Customer support Telegram agent | 1 deployment, DB-backed via secrets | cs-telegram-fd-agent.arrise-ai-services-prod.arriselabs.net |
| `finops-agent` | FinOps / cost intelligence agent | (namespace with SA only) | — |
| `grafana` | Metrics dashboards | Grafana v12.3.1, 1 deployment, 10Gi PVC | grafana.arrise-ai-services-prod.arriselabs.net |
| `gs-stub` | GS (Game Server?) stub service | 1 deployment + ingress | gs-stub.arrise-ai-services-prod.arriselabs.net |
| `karpenter` | Node autoscaler | Karpenter v1.9.0, 3 NodePools (default/test-app/vllm) | — |
| `langfuse` | LLM observability / tracing platform | Langfuse v3.96.2, ClickHouse, Valkey/Redis, 100Gi+8Gi PVCs | langfuse.arrise-ai-services-prod.arriselabs.net |
| `litellm` | LLM proxy / gateway (prod) | LiteLLM v1.94.1, Presidio PII analyzer, 3 replicas, AWS Bedrock IRSA | litellm.arriselabs.net / litellm.arrise-ai-services-prod.arriselabs.net |
| `litellm-194` | LiteLLM namespace (v1.94.1 — likely staging slot) | Empty (SA only) | — |
| `litellm-test` | LiteLLM proxy (test/staging) | LiteLLM v1.94.1 (ECR image), Presidio, HPA 1-6 | litellm-test.arrise-ai-services-prod.arriselabs.net |
| `loki` | Distributed log storage | Loki v3.6.7 (chart 6.55.0), write×2/backend×2/read×2, 60Gi PVCs | — |
| `mobile-replay` | Mobile session replay service | 1 deployment (ECR v1.0.3), 2Gi PVC | mobile-replay.arrise-ai-services-prod.arriselabs.net |
| `mount-s3` | S3 mount controller/DaemonSet | (namespace with SA only) | — |
| `oligo` | Runtime application security (RASP) | Oligo sensor v5.29.3 (chart 5.29.3), operator + collector + scanner | — |
| `otel-collector` | OpenTelemetry collector | OTel Collector deployment | otel-collector.arrise-ai-services-prod.arriselabs.net |
| `pixel-validation-agent` | Pixel tracking validation AI agent | 1 deployment, DB-backed, HPA | pixel-validation-agent.arrise-ai-services-prod.arriselabs.net |
| `victoria-metrics` | Metrics storage (Prometheus-compatible) | VictoriaMetrics Operator v0.70.1, VMSingle, VMAgent, node-exporter, kube-state-metrics, 200Gi PVCs | vmsingle.arrise-ai-services-prod.arriselabs.net |
| `vllm` | vLLM inference router | lmcache/lmstack-router (session-routing), HPA 1-3, GPU toleration, 1Gi RWX PVC | — |
| `vsix` | VS Code extension server (VSIX hosting) | nginx, 1 deployment + ingress | vsix.arrise-ai-services-prod.arriselabs.net |

---

## ArgoCD Setup

### Overview

- **Version**: ArgoCD v3.0.12 (Helm chart: `argo-cd-8.2.7`)
- **GitOps repo**: `https://gitlab.livetechlabs.net/central-ai/argocd.git`
- **Pattern**: Multi-source — Helm chart + values from `overlays/prod-services/values/<app>/` + extra manifests from `overlays/prod-services/<app>/manifests/`
- **URL**: `https://argocd.arrise-ai-services-prod.arriselabs.net`
- **High Availability**: Redis-HA enabled (3 replicas with HAProxy)

### App-of-Apps

Two root apps manage all workloads:
- `master-arriseai-app-prod` — Production applications
- `master-arriseai-app-dev` — Development/staging applications

### Authentication

SSO via Azure AD / Microsoft Entra:
- Tenant: `214f6519-cd19-4726-a221-b70378e889f6`
- Client ID: `f12f81d1-b5e6-43a2-90ee-78555b70bc19`
- RBAC: Admin access for platform team; `dev-role` (get + sync only) for developers

### IRSA Roles

| Component | IAM Role |
|---|---|
| ArgoCD controller + applicationset | `arn:aws:iam::974842793862:role/argocd-manager-eks-role` |
| Karpenter | `arn:aws:iam::974842793862:role/eks-arrise-ai-services-prod-karpenter-irsa` |
| AWS Load Balancer Controller | `arn:aws:iam::974842793862:role/eks-arrise-ai-services-prod-aws-load-balancer-controller` |
| External DNS | `arn:aws:iam::974842793862:role/eks-arrise-ai-services-prod-external-dns` |
| LiteLLM Bedrock | `arn:aws:iam::974842793862:role/litellm-bedrock-eks-role` |

### Applications and Sync Status (at time of export)

| App | Sync | Health | Notes |
|---|---|---|---|
| alloy | Synced | Healthy | |
| arrise-nexus-ai-web | Synced | Healthy | |
| asana-ui | Synced | Healthy | |
| cs-telegram-fd-agent | Synced | Healthy | |
| grafana | Synced | Healthy | |
| gs-stub | Synced | Healthy | |
| kubecost | **OutOfSync** | Healthy | Review needed |
| langfuse | **OutOfSync** | Healthy | Review needed |
| litellm | Synced | Healthy | |
| litellm-test | Synced | **Progressing** | Deployment in progress |
| loki | **OutOfSync** | Healthy | Review needed |
| master-arriseai-app-dev | Synced | Healthy | Root app-of-apps (dev) |
| master-arriseai-app-prod | Synced | Healthy | Root app-of-apps (prod) |
| mobile-replay | Synced | Healthy | |
| nvidia-device-plugin | Synced | Healthy | GPU node plugin |
| oligo | Synced | Healthy | |
| otel-collector | Synced | Healthy | |
| pixel-validation-agent | Synced | Healthy | |
| victoria-metrics | Synced | Healthy | |
| victoria-metrics-operator | Synced | Healthy | |
| vllm | Synced | Healthy | |
| vsix | Synced | Healthy | |

---

## Infrastructure Components

### Node Autoscaling — Karpenter v1.9.0

Three NodePools:

| NodePool | EC2NodeClass | Nodes | Purpose |
|---|---|---|---|
| `default` | `default` | 8 (on-demand) | General workloads |
| `test-app` | `test-app` | 4 | Test/staging workloads |
| `vllm` | `vllm` | 0 (idle) | GPU nodes for vLLM inference |

The `vllm` NodePool uses GPU instances (nodes tolerate `nvidia.com/gpu=true:NoSchedule`).

### Networking

- **Ingress**: AWS ALB Ingress Controller v2.8.3 via `ingressClassName: alb`
- **ALB Group**: All ingresses share the `tools` ALB group (single ALB)
- **DNS**: External DNS v0.13.6 managing `arrise-ai-services-prod.arriselabs.net` zone
- **TLS**: ALB handles SSL termination (ssl-redirect to 443)
- **ALB Access Logs**: `s3://eks-arrise-ai-services-prod-alb-logs/`

### Storage

| StorageClass | Provisioner | Default | Volume Binding |
|---|---|---|---|
| `gp3` | ebs.csi.aws.com | Yes | WaitForFirstConsumer |
| `ebs-sc` | ebs.csi.aws.com | Yes | WaitForFirstConsumer |
| `gp2` | kubernetes.io/aws-ebs | No | WaitForFirstConsumer |

Total PVC storage: ~513 GiB across all namespaces.

### Secrets Management

- **External Secrets Operator v0.16.2** manages all application secrets from AWS Secrets Manager / Parameter Store
- Secrets are NOT exported in this repository (security). Only secret names are listed in `namespaces/<ns>/misc/secrets-list.txt`
- All secrets reference AWS Secrets Manager via IRSA

### Observability Stack

| Component | Stack | Details |
|---|---|---|
| Metrics | VictoriaMetrics | VMSingle (100Gi), VMAgent scraping, kube-state-metrics, node-exporter |
| Logs | Grafana Loki v3.6.7 | Distributed: 2 write + 2 backend + 2 read pods, 60Gi PVCs, S3 backend |
| Log collection | Grafana Alloy | DaemonSet in `alloy` namespace |
| Dashboards | Grafana v12.3.1 | Persistent 10Gi PVC |
| Tracing / LLM obs | Langfuse v3.96.2 | ClickHouse (100Gi) + Redis/Valkey (8Gi) |
| OTEL | OpenTelemetry Collector | Deployment in `otel-collector` namespace |
| Security RASP | Oligo v5.29.3 | Runtime app protection, no-scan label on system SAs |

---

## AI/ML Workloads

### LiteLLM (LLM Proxy Gateway)

- **Version**: 1.94.1 (Helm chart: `litellm-helm-1.94.1`)
- **Namespace**: `litellm` (prod), `litellm-test` (staging), `litellm-194` (reserved)
- **Replicas**: 3 (prod), HPA 1-6 on CPU 70% / Memory 80%
- **Database**: AWS RDS PostgreSQL at `genai-rds-prod.crwkum84ibib.eu-west-1.rds.amazonaws.com`
- **AWS Bedrock**: Access via IRSA role `litellm-bedrock-eks-role`
- **PII Protection**: Microsoft Presidio Analyzer v2.2.358 + Anonymizer (sidecar services)
- **Public URL**: `https://litellm.arriselabs.net` (also: `litellm.arrise-ai-services-prod.arriselabs.net`)

### vLLM (Self-Hosted Inference)

- **Router**: lmcache/lmstack-router:2025-10-13
- **Routing logic**: Session-based (session_id key), Kubernetes service discovery
- **GPU**: Tolerates `nvidia.com/gpu=true:NoSchedule` for GPU node placement
- **HPA**: 1-3 replicas on CPU 80%
- **Shared PVC**: 1Gi RWX for model sharing between pods
- **PDB**: maxUnavailable=1

### Langfuse (LLM Observability)

- **Version**: Langfuse 3.96.2 (chart: `langfuse-1.4.0`)
- **Components**: Web (2 replicas) + Worker + ClickHouse v25.2.1 + Redis/Valkey v8.0.2
- **Storage**: 100Gi ClickHouse + 8Gi Redis PVCs
- **Public URL**: `https://langfuse.arrise-ai-services-prod.arriselabs.net`

### AI Agents

| Agent | Namespace | Backend | Notes |
|---|---|---|---|
| Pixel Validation Agent | `pixel-validation-agent` | PostgreSQL (via secrets) | HPA enabled |
| CS Telegram FD Agent | `cs-telegram-fd-agent` | PostgreSQL (via secrets) | Telegram bot for customer support |
| Central Agent | `central-agent` | — | Namespace with SA; workloads via ExternalSecrets |
| Asana UI | `asana-ui` | — | Asana integration frontend |
| FinOps Agent | `finops-agent` | — | Cost optimization agent |
| Arrise Nexus AI | `arrise-nexus-ai`, `arrise-nexus-ai-web` | — | Main AI product frontend |

---

## How to Recreate the Cluster from Scratch

### Prerequisites

```bash
# AWS CLI, kubectl, helm, eksctl installed
export AWS_REGION=eu-west-1
export CLUSTER_NAME=arrise-ai-services-prod
export AWS_ACCOUNT=974842793862
```

### Step 1: Create EKS Cluster

```bash
# Create cluster (consult original eksctl/terraform config)
# Key parameters: eu-west-1, account 974842793862
# Node groups: managed on-demand for system; Karpenter for workloads
```

### Step 2: Install Cluster-Level Helm Charts (in order)

```bash
# 1. Karpenter (must be first for node provisioning)
helm upgrade --install karpenter oci://public.ecr.aws/karpenter/karpenter \
  --version 1.9.0 -n karpenter --create-namespace \
  -f helm-values/karpenter-values.yaml

helm upgrade --install karpenter-crd oci://public.ecr.aws/karpenter/karpenter-crd \
  --version 1.9.0 -n karpenter

# Apply NodePools and EC2NodeClasses (see cluster-infra/)
kubectl apply -f cluster-infra/

# 2. EBS CSI Driver
helm upgrade --install aws-ebs-csi-driver aws-ebs-csi-driver/aws-ebs-csi-driver \
  --version 2.24.0 -n kube-system -f helm-values/aws-ebs-csi-driver-values.yaml

# 3. AWS Load Balancer Controller
helm upgrade --install aws-load-balancer-controller eks/aws-load-balancer-controller \
  --version 1.8.4 -n kube-system -f helm-values/aws-load-balancer-controller-values.yaml

# 4. External DNS
helm upgrade --install external-dns-main bitnami/external-dns \
  --version 6.27.0 -n kube-system -f helm-values/external-dns-main-values.yaml

# 5. External Secrets Operator
helm upgrade --install external-secrets external-secrets/external-secrets \
  --version 0.16.2 -n kube-system -f helm-values/external-secrets-values.yaml

# 6. Metrics Server
helm upgrade --install metrics-server metrics-server/metrics-server \
  --version 6.5.5 -n kube-system -f helm-values/metrics-server-values.yaml

# 7. PVC Tagger
helm upgrade --install pvc-tagger pvc-tagger/k8s-pvc-tagger \
  --version 2.0.6 -n kube-system -f helm-values/pvc-tagger-values.yaml
```

### Step 3: Install ArgoCD

```bash
helm upgrade --install argocd argo/argo-cd \
  --version 8.2.7 -n argocd --create-namespace \
  -f helm-values/argocd-values.yaml
```

### Step 4: Bootstrap GitOps (App-of-Apps)

```bash
# Apply the root app-of-apps from the ArgoCD GitLab repo
# https://gitlab.livetechlabs.net/central-ai/argocd.git

# Create the master app pointing to the repo
kubectl apply -f argocd-apps/  # AppProject + Application manifests
```

### Step 5: Install Security & Observability

```bash
# Oligo Runtime Security
helm upgrade --install oligo-sensor oligo/oligo \
  --version 5.29.3 -n oligo --create-namespace \
  -f helm-values/oligo-sensor-values.yaml

# All other workloads (Loki, VictoriaMetrics, Grafana, Langfuse, LiteLLM, vLLM, etc.)
# are managed by ArgoCD from the GitLab repo
```

### IRSA Roles Required

Before deploying, create these IAM roles with appropriate trust policies for the EKS OIDC provider:

- `argocd-manager-eks-role` — ArgoCD controller access to AWS resources
- `eks-arrise-ai-services-prod-karpenter-irsa` — Karpenter EC2 management
- `eks-arrise-ai-services-prod-aws-load-balancer-controller` — ALB management
- `eks-arrise-ai-services-prod-external-dns` — Route53 management
- `litellm-bedrock-eks-role` — Bedrock model access for LiteLLM

---

## Secrets Reference

Secrets are managed by External Secrets Operator and sourced from AWS Secrets Manager.  
No secret values are stored in this repository.

| Namespace | Secret Name | Purpose |
|---|---|---|
| `litellm` | `litellm-masterkey-creds` | LiteLLM master API key |
| `litellm` | `litellm-rds-creds` | RDS PostgreSQL credentials |
| `langfuse` | `langfuse-secrets` | NextAuth salt, encryption key, DB credentials |
| `vllm` | `vllm-poc-token` | vLLM API authentication token |
| `vllm` | `vllm-stack-secrets` | vLLM stack configuration secrets |
| `victoria-metrics` | `vmagent-vm-stack` | VMAgent scrape credentials |
| `argocd` | `argocd-azure-sso-creds` | Azure AD OAuth client secret |

For full secrets list per namespace, see: `namespaces/<namespace>/misc/secrets-list.txt`

---

## Key Observations

1. **Three OutOfSync apps**: `kubecost`, `langfuse`, `loki` — these have drift from GitOps repo and need investigation
2. **GPU support**: vLLM NodePool with GPU nodes, nvidia-device-plugin deployed — GPU inference is supported but NodePool had 0 nodes at export time
3. **AWS Bedrock integration**: LiteLLM uses IRSA to call Bedrock models (no API keys stored)
4. **Multi-instance LiteLLM**: Both `litellm` (3 replicas, prod) and `litellm-test` (HPA 1-6, staging) run v1.94.1
5. **PII protection**: Microsoft Presidio Analyzer + Anonymizer deployed alongside LiteLLM for data protection
6. **Base domain**: `arrise-ai-services-prod.arriselabs.net` with some apps also on `arriselabs.net` apex (litellm, nexusai)
7. **RDS**: External PostgreSQL at `genai-rds-prod.crwkum84ibib.eu-west-1.rds.amazonaws.com` (eu-west-1)
8. **Session token expiry**: ArgoCD Application CRD manifests and cluster-infra full YAML were not captured (token expired mid-export). See `argocd-apps/ARGOCD-APPS-INDEX.yaml` and `cluster-infra/*.yaml` for documented observations.

---

## Re-running the Export

With fresh AWS credentials:

```bash
export AWS_ACCESS_KEY_ID=...
export AWS_SECRET_ACCESS_KEY=...
export AWS_SESSION_TOKEN=...
export AWS_DEFAULT_REGION=eu-west-1

# Re-export ArgoCD apps
kubectl --context=ai get applications.argoproj.io -n argocd -o yaml > /tmp/argocd-apps.yaml

# Re-export Karpenter resources
kubectl --context=ai get nodepools.karpenter.sh -o yaml > /tmp/nodepools.yaml
kubectl --context=ai get ec2nodeclasses.karpenter.k8s.aws -o yaml > /tmp/nodeclasses.yaml

# Re-export cluster-infra
kubectl --context=ai get storageclasses,ingressclasses,clusterroles,clusterrolebindings -o yaml
```
