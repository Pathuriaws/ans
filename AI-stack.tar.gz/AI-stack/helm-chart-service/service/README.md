# service


## Generating a secret

Path to secret in Vault will be generated like:
```
key: infra/k8s/{{ .Values.secret.cluster }}/{{ .Values.labels.app }}/{{ .Values.secret.name }}
```
Create it first before using. [Vault](https://vault-prod.livetechlabs.net/)

